import xbmc

def main():
    # Your NFT marketplace code here
    xbmc.log("Hello from Wolfies Addon!")

if __name__ == '__main__':
    main()
